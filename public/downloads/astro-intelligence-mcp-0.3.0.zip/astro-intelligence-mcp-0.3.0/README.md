# ASTRO Intelligence MCP 0.3.0

Read-only access to the complete signal, context and basket API responses.
No paper execution, private orders or account balances. No trade execution tools.

## Installation from this extracted folder

Python 3.10+ is required. Use a separate virtual environment.

Windows PowerShell:

    python -m venv .venv
    .\.venv\Scripts\python.exe -m pip install ".[mcp]"
    .\.venv\Scripts\astro-mcp.exe configure

macOS/Linux terminal:

    python3 -m venv .venv
    .venv/bin/python -m pip install '.[mcp]'
    .venv/bin/astro-mcp configure

Configure asks for the key with hidden input and stores it in a native OS
credential store. Do not put your key in command arguments, environment examples,
client JSON, screenshots or chat. Windows Credential Manager, macOS Keychain,
or Linux Secret Service is required. Headless plaintext fallback is not enabled.

In your MCP client, set command to the absolute installed astro-mcp executable,
and args to ["serve"], using stdio transport. No credentials in that configuration.

New users: https://astro-event-horizon.vercel.app/trial . Verify email on the
website, not through the AI. Existing paid/founding users use their existing key.

Read docs/MCP.md for tools, caching, rate limits and trial conditions.
Use MANIFEST.sha256.json to verify source-file hashes. This package is not a
PyPI publication and does not automatically install itself in AI clients.
